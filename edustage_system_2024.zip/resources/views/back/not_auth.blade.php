<!DOCTYPE html>
<html lang="en">
	
<!-- Mirrored from laravel.spruko.com/dashfox/ltr/error404 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 30 Mar 2021 20:07:51 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="Description" content="Dashfox - Laravel Admin & Dashboard Template">
		<meta name="Author" content="Spruko Technologies Private Limited">
		<meta name="Keywords" content="admin template, admin dashboard, bootstrap dashboard template, bootstrap 4 admin template, laravel, php framework, php laravel, laravel framework, php mvc, laravel admin panel, laravel admin panel, laravel template, laravel bootstrap, blade laravel, best php framework"/>

		<!-- Title -->
		<title> Dashfox - Laravel Admin & Dashboard Template </title>

		<!-- Favicon -->
		<link rel="icon" href="{{ asset('back') }}/assets/img/brand/favicon.png" type="image/x-icon"/>

		<!-- Bootstrap css -->
		<link href="{{ asset('back') }}/assets/plugins/bootstrap/css/bootstrap.css" rel="stylesheet" />

		<!-- Icons css -->
		<link href="{{ asset('back') }}/assets/plugins/icons/icons.css" rel="stylesheet">

		<!--  Right-sidemenu css -->
		<link href="{{ asset('back') }}/assets/plugins/sidebar/sidebar.css" rel="stylesheet">

		<!--  Left-Sidebar css -->
		<link rel="stylesheet" href="{{ asset('back') }}/assets/css/sidemenu.css">

		<!--- Dashboard-2 css-->
		<link href="{{ asset('back') }}/assets/css/style.css" rel="stylesheet">
		<link href="{{ asset('back') }}/assets/css/style-dark.css" rel="stylesheet"> 

		<!--- Color css-->
		<link id="theme" href="{{ asset('back') }}/assets/css/colors/color.css" rel="stylesheet">

		 

		<!--- Internal Fontawesome css-->
		<link href="{{ asset('back') }}/assets/plugins/fontawesome-free/css/all.min.css" rel="stylesheet">

		<!---Ionicons css-->
		<link href="{{ asset('back') }}/assets/plugins/ionicons/css/ionicons.min.css" rel="stylesheet">

		<!---Internal Typicons css-->
		<link href="{{ asset('back') }}/assets/plugins/typicons.font/typicons.css" rel="stylesheet">

		<!---Internal Feather css-->
		<link href="{{ asset('back') }}/assets/plugins/feather/feather.css" rel="stylesheet">

		<!---Internal Falg-icons css-->
		<link href="{{ asset('back') }}/assets/plugins/flag-icon-css/css/flag-icon.min.css" rel="stylesheet">


		<!---Skinmodes css-->
		<link href="{{ asset('back') }}/assets/css/skin-modes.css" rel="stylesheet" />

		<!--- Animations css-->
		<link href="{{ asset('back') }}/assets/css/animate.css" rel="stylesheet">

	</head>

    <body class="main-body light-theme">

		<!-- Loader -->
		<div id="global-loader">
			<img src="{{ asset('back') }}/assets/img/loader-2.svg" class="loader-img" alt="Loader">
		</div>
		<!-- /Loader -->

		<!-- main-signin-wrapper -->

        <div class="my-auto page page-h">

            		 
		<!-- Main-error-wrapper -->
        <div class="main-error-wrapper error-wrapper page page-h">
			<h1 class="">401</h1>
			<h2> Sorry, an error has occured, Not Authorizad To Login this Page!.</h2>
			<h6>please!! Enter Yoyr Email And Your Password To Login</h6>
			<a class="btn btn-primary" href="{{ asset('dashboard') }}/login">Back to Login Page</a>
		</div>
		<!-- /Main-error-wrapper -->


        </div>

		<!-- /main-signin-wrapper -->

        <!-- JQuery min js -->
<script src="{{ asset('back') }}/assets/plugins/jquery/jquery.min.js"></script>

<!-- Bootstrap4 js-->
<script src="{{ asset('back') }}/assets/plugins/bootstrap/popper.min.js"></script>
<script src="{{ asset('back') }}/assets/plugins/bootstrap/js/bootstrap.min.js"></script>

<!-- Ionicons js -->
<script src="{{ asset('back') }}/assets/plugins/ionicons/ionicons.js"></script>

<!-- Moment js -->
<script src="{{ asset('back') }}/assets/plugins/moment/moment.js"></script>

<!-- eva-icons js -->
<script src="{{ asset('back') }}/assets/plugins/eva-icons/eva-icons.min.js"></script>
  
<!-- Rating js-->
<script src="{{ asset('back') }}/assets/plugins/rating/jquery.rating-stars.js"></script>
<script src="{{ asset('back') }}/assets/plugins/rating/jquery.barrating.js"></script>

 


<!-- custom js -->
<script src="{{ asset('back') }}/assets/js/custom.js"></script>
        
	</body>

<!-- Mirrored from laravel.spruko.com/dashfox/ltr/error404 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 30 Mar 2021 20:07:51 GMT -->
</html>