<?php

return [
    /* ... other validation messages ... */

    // 'password.required' => 'حقل كلمة المرور مطلوب.',
    // 'password.string' => 'يجب أن تكون كلمة المرور سلسلة نصية.',
    // 'password.min' => 'يجب أن تحتوي كلمة المرور على 8 أحرف على الأقل.',
    // 'password.mixedCase' => 'يجب أن تحتوي كلمة المرور على أحرف كبيرة وصغيرة.',
    // 'password.numbers' => 'يجب أن تحتوي كلمة المرور على أرقام.',
    // 'password.symbols' => 'يجب أن تحتوي كلمة المرور على رموز.',
    // 'password.uncompromised' => 'كلمة المرور هذه قد تم تسريبها، يرجى اختيار كلمة مرور جديدة.',
    // 'password.confirmed' => 'يجب تأكيد كلمة المرور.',
];
